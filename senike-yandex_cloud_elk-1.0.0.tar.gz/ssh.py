with open('/home/se/.ssh/id_rsa.pub', 'r') as f:
    ssh_key = f.read().strip()  # Удаляем пробелы и символы новой строки
    print(ssh_key)